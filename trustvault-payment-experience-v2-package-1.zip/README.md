# TrustVault Payment Experience v2 — Package 1

This package enhances the existing Marketplace payment experience without changing the payment engine.

## Included

- Verified seller destination card
- Arc Testnet, USDC and protected-settlement badges
- Seller wallet copy and ArcScan actions
- Improved payment and fee summary
- Live transaction progress inside final approval
- Existing Circle App Kit estimate, send, Arc confirmation, TrustPoints and receipt flow preserved

## Apply

From the TrustVault project root:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\apply-payment-experience-v2-package-1.ps1
```

Then run:

```powershell
npm.cmd run build
```

## Test

Marketplace → Cart → Checkout → Payment Review

Confirm:
1. Seller shows as verified.
2. Settlement wallet can be copied.
3. ArcScan opens the seller address.
4. Fee estimate appears.
5. Progress changes during approval and confirmation.
6. Successful payment still opens the receipt.

## Rollback

The installer creates a timestamped backup under:

`trustvault-package-backups\payment-experience-v2-package-1-*`

Copy the backed-up files back to their original paths if required.
