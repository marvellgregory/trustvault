$ErrorActionPreference = "Stop"

$projectRoot = (Get-Location).Path
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$filesRoot = Join-Path $packageRoot "files"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $projectRoot "trustvault-package-backups\payment-experience-v2-package-1-$timestamp"

$relativeFiles = @(
  "components\marketplace\payment-review\PaymentEstimateCard.tsx",
  "components\marketplace\payment-review\MarketplacePaymentApprovalCard.tsx"
)

if (-not (Test-Path (Join-Path $projectRoot "package.json"))) {
  throw "Run this installer from the TrustVault project root."
}

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

foreach ($relativePath in $relativeFiles) {
  $currentPath = Join-Path $projectRoot $relativePath
  $packagePath = Join-Path $filesRoot $relativePath
  $backupPath = Join-Path $backupRoot $relativePath

  if (-not (Test-Path $packagePath)) {
    throw "Package file missing: $relativePath"
  }

  if (Test-Path $currentPath) {
    New-Item -ItemType Directory -Path (Split-Path $backupPath -Parent) -Force | Out-Null
    Copy-Item $currentPath $backupPath -Force
  }

  New-Item -ItemType Directory -Path (Split-Path $currentPath -Parent) -Force | Out-Null
  Copy-Item $packagePath $currentPath -Force
  Write-Host "Updated $relativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "Payment Experience v2 Package 1 applied." -ForegroundColor Green
Write-Host "Backup: $backupRoot" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next command: npm.cmd run build" -ForegroundColor Yellow
